package com.example.trackerplane                                                                    // Définit le package pour organiser les classes dans le module "trackerplane".
import android.os.Bundle                                                                            // Importation nécessaire pour stocker des données dans des clés-valeurs.
import androidx.activity.ComponentActivity                                                          // Permet de gérer une activité dans une application Android.
import androidx.activity.compose.setContent                                                         // Permet de définir le contenu d'une activité avec Composables.
import androidx.compose.foundation.background                                                       // Permet d'ajouter une couleur de fond à un composant.
import androidx.compose.foundation.layout.*                                                         // Permet d'utiliser des mises en page (colonnes, rangées, etc.).
import androidx.compose.material3.Button                                                            // Importation du bouton de la bibliothèque Material Design 3.
import androidx.compose.material3.ButtonDefaults                                                    // Définit les paramètres par défaut pour le bouton.
import androidx.compose.material3.Scaffold                                                          // Permet de créer une structure de base pour l'écran, avec une barre d'outils, etc.
import androidx.compose.material3.Text                                                              // Permet d'afficher du texte à l'écran.
import androidx.compose.material3.TextField                                                         // Permet de créer un champ de texte où l'utilisateur peut saisir des informations.
import androidx.compose.runtime.*                                                                   // Permet de gérer l'état de l'interface utilisateur.
import androidx.compose.ui.Alignment                                                                 // Permet d'aligner des éléments dans un composant.
import androidx.compose.ui.Modifier                                                                 // Permet de modifier un composant (ajouter des marges, changements de style, etc.).
import androidx.compose.ui.graphics.Color                                                           // Permet de manipuler les couleurs des composants.
import androidx.compose.ui.text.font.FontWeight                                                      // Permet de définir le poids (gras, léger, etc.) de la police de texte.
import androidx.compose.ui.text.style.TextAlign                                                     // Permet de définir l'alignement du texte (gauche, centré, etc.).
import androidx.compose.ui.tooling.preview.Preview                                                  // Permet de prévisualiser un composant dans l'éditeur.
import androidx.compose.ui.unit.dp                                                                  // Permet de définir des tailles en "dp" (density-independent pixels).
import androidx.compose.ui.unit.sp                                                                  // Permet de définir des tailles de texte en "sp" (scale-independent pixels).
import androidx.compose.foundation.shape.RoundedCornerShape                                          // Permet de créer des formes avec des coins arrondis.
import androidx.compose.ui.graphics.Brush                                                            // Permet de créer des dégradés ou des motifs pour les couleurs de fond.
import com.example.trackerplane.ui.theme.TrackerPlaneTheme                                           // Permet d'appliquer un thème spécifique à l'application.
import kotlinx.coroutines.delay                                                                     // Permet d'introduire des délais dans l'exécution (par exemple, pour les animations).
import androidx.compose.ui.text.input.PasswordVisualTransformation                                   // Permet de masquer le mot de passe dans un champ texte.
import java.text.SimpleDateFormat                                                                    // Permet de formater les dates dans un format spécifique.
import java.util.Date                                                                               // Permet de manipuler les dates et heures.
import java.util.Locale                                                                             // Permet d'afficher les dates dans un format localisé.
import androidx.compose.foundation.lazy.LazyColumn                                                  // Permet d'afficher une liste déroulante avec des éléments.
import androidx.compose.foundation.lazy.items                                                       // Permet de créer une liste d'éléments dans une LazyColumn.
import androidx.compose.foundation.clickable                                                        // Permet de rendre un composant réactif au clic de l'utilisateur.



// Déclare la classe MainActivity qui hérite de ComponentActivity.//
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {                                            // Méthode appelée lors de la création de l'activité.
        super.onCreate(savedInstanceState)                                                          // Appelle la méthode parente pour initialiser l'activité.
        setContent {                                                                                // Définit le contenu de l'activité avec un composable.
            TrackerPlaneTheme {                                                                     // Applique le thème "TrackerPlane" à l'interface.
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->                       // Crée une structure de base (Scaffold) qui remplit l'écran.
                    MainContent(                                                                    // Ajoute le composable "MainContent" à l'écran.
                        modifier = Modifier                                                         // Applique des modifications au composable "MainContent".
                            .padding(innerPadding)                                                  // Ajoute un padding basé sur l'espace interne du Scaffold.
                            .background(                                                            // Définit un fond pour le "MainContent".
                                brush = Brush.verticalGradient(                                     // Utilise un dégradé vertical pour le fond.
                                    colors = listOf(Color(0xFFB3E5FC), Color(0xFF03A9F4)) // Spécifie les couleurs du dégradé.
                                )
                            )
                    )
                }
            }
        }
    }
}

//INTERFACE DE LA PAGE D'OUVERTURE//
@Composable
fun MainContent(modifier: Modifier = Modifier) {
    var isDarkMode by remember { mutableStateOf(false) }                                      // Variable pour le mode clair/sombre
    var showLoginForm by remember { mutableStateOf(false) }                                   // Variable pour afficher ou masquer le formulaire de connexioN
    var showSignupForm by remember { mutableStateOf(false) }                                  // Variable pour afficher ou masquer le formulaire d'inscription
    var showSearchScreen by remember { mutableStateOf(false) }                                // Variable pour afficher ou masquer l'écran de recherche
    var showValidationScreen by remember { mutableStateOf(false) }                            // Variable pour afficher ou masquer l'écran de validation
    var showScanScreen by remember { mutableStateOf(false) }                                  // Variable pour afficher ou masquer l'écran de scan

    // Variable de langue (français/anglais)
    var language by remember { mutableStateOf("fr") }                                         // Variable  "language" qui détermine la langue de l'interface

    // Fonction pour changer la langue
    fun toggleLanguage() {                                                                           // Définit une fonction qui permet de basculer entre les langues.
        // Si la langue actuelle est le français ("fr"), la fonction la change en anglais ("en"), et inversement.
        language = if (language == "fr") "en" else "fr"
    }

// Obtenir et mettre à jour la date et l'heure toutes les secondes
    var currentDateTime by remember { mutableStateOf("") }                                    // Crée une variable d'état pour stocker la date et l'heure actuelles sous forme de chaîne de caractères.

    LaunchedEffect(Unit) {                                                                          // Lancement d'un effet qui s'exécute au démarrage de la composition.
        while (true) {  // Démarre une boucle infinie pour mettre à jour la date et l'heure.
            currentDateTime = SimpleDateFormat("dd/MM/yyyy HH:mm:ss ", Locale.getDefault()).format(Date())  // Formate la date et l'heure actuelles selon le format spécifié ("jour/mois/année heure:minute:seconde") et la locale par défaut.
            delay(1000L)  // Attend 1 seconde avant de mettre à jour la date et l'heure à nouveau.
        }
    }


    // Choix des couleurs en fonction du mode
    val backgroundColor = if (isDarkMode) Color(0xFF121212) else Color(0xFFBBDEFB)       // Si le mode sombre est activé, la couleur de fond en gris , sinon en bleu clair
    val textColor = if (isDarkMode) Color(0xFFFFFFFF) else Color(0xFF000000)             // Si le mode sombre est activé, la couleur du texte en blanc  sinon en noir

// Box, qui est un conteneur pour d'autres éléments UI
    Box(
        modifier = modifier                                                                          // Applique le modifier passé en paramètre à ce composant Box.
            .fillMaxSize()                                                                           // Permet à la Box de remplir toute la taille de son parent (l'écran ici).
            .background(backgroundColor)                                                            // Applique une couleur `backgroundColor`, qui change en fonction du mode
    ) {
        // Conteneur principal de la colonne, qui occupe tout l'espace disponible
        Column(
            modifier = Modifier
                .fillMaxSize()                                                                       // La colonne occupe toute la taille disponible de l'écran
                .padding(16.dp),                                                                    // Ajout d'un padding de 16dp autour de la colonne pour espacer les éléments de l'écran
            horizontalAlignment = Alignment.CenterHorizontally,                                     // Centrer les éléments horizontalement dans la colonne
            verticalArrangement = Arrangement.Top                                                   // Placer les éléments en haut de la colonne
        ) {
            // Affichage du titre "Plane Tracker"
            Text(
                text = if (language == "fr") "✈Plane Tracker✈" else "✈Plane Tracker✈",            // Texte statique, "Plane Tracker" est affiché indépendamment de la langue
                fontSize = 32.sp,                                                                   // Taille de la police du texte (32sp)
                fontWeight = FontWeight.Bold,                                                       // Le texte est en gras
                color = textColor,                                                                  // La couleur du texte est définie par la variable `textColor`
                modifier = Modifier.padding(top = 32.dp),                                           // Un padding supplémentaire en haut de 32dp pour espacer le titre des éléments au-dessus
                textAlign = TextAlign.Center                                                        // Le texte est centré horizontalement
            )


        // Affichage de la date et de l'heure actuelles
            Text(
                text = currentDateTime,                                                              // Affiche  la date et l'heure actuelles
                fontSize = 18.sp,                                                                    // Définit la taille du texte à 18 sp
                color = textColor,                                                                   // Utilise la couleur définie  `textColor` pour le texte
                modifier = Modifier.padding(top = 8.dp),                                             // Ajoute un espacement de 8 dp en haut du texte
                textAlign = TextAlign.Center                                                         // Centre le texte horizontalement
            )




            Spacer(modifier = Modifier.height(120.dp))

            // Vérification des écrans (connexion, inscription, etc.)
            when {
                // Si le formulaire de connexion doit être affiché
                showLoginForm -> LoginForm(
                    onBack = { showLoginForm = false },                                             // Revenir en arrière en cachant le formulaire de connexion
                    onLoginSuccess = { showSearchScreen = true }                                     // Afficher l'écran de recherche en cas de succès de la connexion
                )

                // Si le formulaire d'inscription doit être affiché
                showSignupForm -> SignupForm(onBack = { showSignupForm = false })                   // Cacher le formulaire d'inscription

                // Si l'écran de recherche doit être affiché
                showSearchScreen -> SearchScreen(
                    onBack = { showSearchScreen = false },                                           // Cacher l'écran de recherche
                    onSearch = { query ->                                                            // Effectuer une recherche en fonction de la requête
                        println("Recherche pour: $query")                                           // Afficher la requête dans la console
                        showValidationScreen = true                                                 // Afficher l'écran de validation après la recherche
                    }
                )

                // Si l'écran de validation doit être affiché
                showValidationScreen -> ValidationScreen(
                    onBack = { showValidationScreen = false },                                      // Revenir en arrière et cacher l'écran de validation
                    onGoToScan = { showScanScreen = true }                                          // Afficher l'écran de scan après validation
                )

                // Si l'écran de scan doit être affiché
                showScanScreen -> ScanScreen(onBack = { showScanScreen = false })                   // Cacher l'écran de scan

                else -> {
                    // Si aucune des conditions précédentes n'est remplie, afficher les boutons de Connexion et Inscription
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,                          // Centrer les boutons horizontalement
                        verticalArrangement = Arrangement.Center                                    // Centrer les boutons verticalement
                    ) {
                        // Bouton de connexion
                        Button(
                            onClick = { showLoginForm = true },  // Afficher le formulaire de connexion
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A65)),  // Couleur orange pour le bouton
                            shape = RoundedCornerShape(30),  // Coins arrondis
                            modifier = Modifier
                                .width(220.dp)                                                      // Largeur du bouton
                                .height(55.dp)                                                      // Hauteur du bouton
                                .padding(vertical = 8.dp)                                           // Espacement vertical autour du bouton
                        ) {
                            Text(
                                text = if (language == "fr") "Connexion" else "Login",              // Texte selon la langue
                                color = Color.White,                                                // Couleur du texte en blanc
                                fontSize = 18.sp,                                                   // Taille de la police
                                fontWeight = FontWeight.SemiBold                                     // Police semi-grasse
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))                                   // Espace entre les deux boutons

                        // Bouton d'inscription
                        Button(
                            onClick = { showSignupForm = true },                                     // Afficher le formulaire d'inscription
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4DB6AC)),  // Couleur verte pour le bouton
                            shape = RoundedCornerShape(30),                                  // Coins arrondis
                            modifier = Modifier
                                .width(220.dp)                                                      // Largeur du bouton
                                .height(55.dp)                                                      // Hauteur du bouton
                                .padding(vertical = 8.dp)                                            // Espacement vertical autour du bouton
                        ) {
                            Text(
                                text = if (language == "fr") "S'inscrire" else "Sign Up",           // Texte selon la langue
                                color = Color.White,                                                // Couleur du texte en blanc
                                fontSize = 18.sp,                                                   // Taille de la police
                                fontWeight = FontWeight.SemiBold                                     // Police semi-grasse
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))                                                // Ajout d'un espacement vertical avant le bouton de bascule


// Définition du bouton de bascule
            Button(
                // Lorsque l'utilisateur clique sur le bouton, on inverse la valeur de 'isDarkMode'
                onClick = { isDarkMode = !isDarkMode },

                // Définition des couleurs du bouton selon le mode
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDarkMode) Color(0xFFBBDEFB) else Color(0xFF303030)
                )
            ) {
                Text(if (isDarkMode) "Mode Clair" else "Mode Sombre", color = Color.White)           // Texte du bouton selon le mode : "Mode Clair" si en mode sombre, sinon "Mode Sombre"

            }


            Spacer(modifier = Modifier.height(16.dp))                                               // Ajouter un espace vertical de 16dp avant le bouton

            Button(                                                                                  // Définition du bouton avec plusieurs options de personnalisation
                onClick = { toggleLanguage() },                                                     // Action exécutée lors du clic sur le bouton
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),      // Définir la couleur de fond du bouton
                shape = RoundedCornerShape(30),                                              // Appliquer une forme arrondie aux coins du bouton
                modifier = Modifier                                                                  // Définir les dimensions et le padding du bouton
                    .width(220.dp)                                                                  // Largeur du bouton
                    .height(55.dp)                                                                  // Hauteur du bouton
                    .padding(vertical = 8.dp)                                                       // Padding vertical de 8dp
            ) {
                Text( // Contenu du bouton : un texte qui change en fonction de la langue
                    text = if (language == "fr") "Changer en Anglais" else "Switch to French",      // Le texte change en fonction de la langue (français ou anglais)
                    color = Color.White,                                                            // Couleur du texte en blanc
                    fontSize = 18.sp,                                                               // Taille de la police du texte
                    fontWeight = FontWeight.SemiBold                                                 // Poids de la police (semi-gras)
                )
            }

        }

// Texte "Par ANTON NELCON Steve" en bas
        Text(
            text = "Par ANTON NELCON Steve",                                                        // Le texte affiché en bas de l'écran, ici le nom
            fontSize = 16.sp,                                                                       // La taille de la police est définie sur 16 "sp" .
            color = textColor,                                                                      // La couleur du texte  du mode clair/sombre .
            modifier = Modifier.padding(bottom = 16.dp),                                            // Ajoute un padding de 16 "dp"
            textAlign = TextAlign.Center                                                            // Centre le texte horizontalement dans son conteneur.
        )

    }
}



//INTERFACE DE CONNEXION//
@Composable
fun LoginForm(onBack: () -> Unit, onLoginSuccess: () -> Unit) {                                     // Fonction principale du formulaire de connexion
    // Déclaration des états pour l'email et le mot de passe
    var email by remember { mutableStateOf("") }                                               // Variable pour stocker l'email saisi
    var password by remember { mutableStateOf("") }                                            // Variable pour stocker le mot de passe saisi

    // Messages pour afficher des informations générales ou des erreurs spécifiques
    var message by remember { mutableStateOf("") }                                             // Variable pour les messages généraux (ex: succès de connexion)
    var errorMessage by remember { mutableStateOf("") }                                        // Variable pour afficher des erreurs spécifiques (ex: email incorrect)

    // Variable pour gérer la langue de l'interface (français par défaut)
    var language by remember { mutableStateOf("fr") }

    // Fonction pour changer la langue de l'interface (français/anglais)
    fun toggleLanguage() {
        language = if (language == "fr") "en" else "fr"                                              // Change la langue entre "fr" et "en"
    }



    // Utilisation de Column pour organiser les éléments verticalement
    Column(
        modifier = Modifier
            .fillMaxWidth()                                                                          // La colonne prend toute la largeur disponible
            .padding(horizontal = 24.dp, vertical = 32.dp)                                           // Espacement interne (padding) horizontal et vertical
            .background(
                color = Color.White,                                                                 // Couleur de fond de la colonne (blanc ici)
                shape = RoundedCornerShape(20.dp)                                                   // Coins arrondis avec un rayon de 20 dp
            )
            .padding(16.dp),                                                                         // Espacement interne supplémentaire autour du contenu de la colonne
        horizontalAlignment = Alignment.CenterHorizontally,                                         // Aligne les éléments horizontalement au centre
        verticalArrangement = Arrangement.Top                                                        // Aligne les éléments verticalement en haut de la colonne
    ) {
        // Texte du titre du formulaire
        Text(
            text = if (language == "fr") "Formulaire de Connexion" else "Login Form",                // Texte dynamique selon la langue
            fontSize = 20.sp,                                                                       // Taille de la police (20 sp)
            fontWeight = FontWeight.Bold,                                                           // Poids de la police en gras
            color = Color(0xFF0288D1),                                                         // Couleur du texte (bleu ici)
            textAlign = TextAlign.Center                                                            // Centrage du texte
        )
        Spacer(modifier = Modifier.height(16.dp))                                                    // Espacement vertical entre le titre et les autres éléments


        // Barre pour l'email
        TextField(
            value = email,                                                                          // La valeur du champ de texte est liée à la variable 'email'
            onValueChange = { email = it },                                                         // Lorsqu'il y a un changement dans le champ, la variable 'email' est mise à jour
            label = { Text(if (language == "fr") "Adresse Mail" else "Email Address") },             // Le label change en fonction de la langue sélectionnée (français ou anglais)
            isError = errorMessage.isNotEmpty(),                                                     // Si un message d'erreur existe, le champ est marqué comme incorrect
            modifier = Modifier
                .fillMaxWidth()                                                                     // Le champ prend toute la largeur disponible
                .padding(vertical = 4.dp)                                                           // Un petit espacement vertical autour du champ de texte
        )

// Affichage du message d'erreur pour l'email
        if (errorMessage.isNotEmpty()) {                                                             // Si un message d'erreur existe
            Text(
                text = errorMessage,                                                                 // Affiche le message d'erreur
                color = Color.Red,                                                                   // Le texte d'erreur est en rouge
                fontSize = 14.sp,                                                                    // Taille du texte d'erreur est de 14 sp
                modifier = Modifier.align(Alignment.Start)                                           // Aligne le texte d'erreur à gauche
            )
        }

        Spacer(modifier = Modifier.height(8.dp))                                                    // Ajoute un espacement vertical de 8 dp après le champ de texte

        TextField(                                                                                  // Définition du champ de texte pour le mot de passe
            value = password,                                                                       // Valeur actuelle du mot de passe
            onValueChange = { password = it },                                                      // Mise à jour de la valeur du mot de passe lorsqu'il est modifié
            label = { Text(if (language == "fr") "Mot de passe" else "Password") },                 // Étiquette qui change selon la langue (français ou anglais)
            visualTransformation = PasswordVisualTransformation(),                                   //Mot de passe masqué
            modifier = Modifier                                                                     // Modificateur pour la mise en forme du champ de texte
                .fillMaxWidth()                                                                     // Remplir toute la largeur disponible
                .padding(vertical = 4.dp)                                                           // Padding vertical de 4dp autour du champ de texte
        )

        Spacer(modifier = Modifier.height(8.dp))                                                    // Ajouter un espace vertical de 8dp après le champ de texte


        // Affichage du message général
        if (message.isNotEmpty()) {                                                                  // Vérifier si le message n'est pas vide
            Text(
                text = message,                                                                      // Afficher le message
                color = Color.Green,                                                                 // Couleur verte du texte
                fontSize = 14.sp,                                                                   // Taille de police 14sp
                fontWeight = FontWeight.Bold,                                                       // Poids de la police en gras
                modifier = Modifier.padding(vertical = 8.dp)                                        // Padding vertical de 8dp
            )
        }

// Bouton de connexion
        Button(
            onClick = {                                                                            // Action lors du clic sur le bouton
                errorMessage = "" // Réinitialiser l'erreur
                if (!email.contains(".com")) {                                                // Vérifier si l'email contient ".com"
                    errorMessage = if (language == "fr")                                            // Message d'erreur en français
                        "Veuillez écrire un e-mail valide (.com)"
                    else // Message d'erreur en anglais
                        "Please enter a valid email address"
                } else if (email.isNotBlank() && password.isNotBlank()) { // Vérifier si les champs email et mot de passe sont remplis
                    message = if (language == "fr")                                                 // Message de succès en français
                        "Identifiant et mot de passe valides"
                    else // Message de succès en anglais
                        "Username and password valid"
                    println("Connexion réussie avec $email")                                        // Afficher la connexion réussie dans la console
                    onLoginSuccess()                                                                // Appeler la fonction de succès de connexion
                } else {                                                                            // Si les champs ne sont pas remplis
                    message = if (language == "fr")                                                  // Message d'erreur en français
                        "Veuillez remplir tous les champs"
                    else                                                                            // Message d'erreur en anglais
                        "Please fill all fields"
                }
            },
            colors = ButtonDefaults.buttonColors(Color(0xFF03A9F4)),                          // Couleur bleue du bouton
            shape = RoundedCornerShape(50),                                                  // Coins arrondis du bouton
            modifier = Modifier                                                                     // Modificateur pour la mise en forme du bouton
                .fillMaxWidth()                                                                     // Remplir toute la largeur
                .height(50.dp)                                                                      // Hauteur de 50dp
        ) {
            Text(
                text = if (language == "fr") "Se connecter" else "Log In",                          // Texte du bouton en fonction de la langue
                color = Color.White,                                                                // Couleur du texte en blanc
                fontSize = 16.sp                                                                    // Taille de la police du texte
            )
        }
        Spacer(modifier = Modifier.height(8.dp))                                                    // Ajouter un espace vertical de 8dp après le bouton

// Bouton retour
        Button(
            onClick = onBack,                                                                       // Action pour revenir en arrière
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                           // Couleur bleue du bouton
            shape = RoundedCornerShape(50),                                                  // Coins arrondis du bouton
            modifier = Modifier                                                                     // Modificateur pour la mise en forme du bouton
                .fillMaxWidth()                                                                     // Remplir toute la largeur
                .height(50.dp)                                                                      // Hauteur de 50dp
        ) {
            Text(
                text = if (language == "fr") "Retour" else "Back",                                  // Texte du bouton en fonction de la langue
                color = Color.White,                                                                 // Couleur du texte en blanc
                fontSize = 16.sp                                                                    // Taille de la police du texte
            )
        }

        Spacer(modifier = Modifier.height(16.dp))                                                    // Ajouter un espace vertical de 16dp après le bouton


        // Bouton Langue
        Button(                                                                                     // Crée un bouton interactif.
            onClick = { toggleLanguage() },                                                         // Définit l'action à exécuter lors du clic : appeler la fonction "toggleLanguage" pour changer la langue.
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),          // Définit la couleur de fond du bouton (bleu ici).
            shape = RoundedCornerShape(30),                                                 // Donne au bouton des coins arrondis avec un rayon de 30.
            modifier = Modifier                                                                     // Applique des modifications au bouton.
                .width(220.dp)                                                                      // Définit la largeur du bouton à 220 "dp" (density-independent pixels).
                .height(55.dp)                                                                      // Définit la hauteur du bouton à 55 "dp".
                .padding(vertical = 8.dp)                                                           // Ajoute un espacement vertical de 8 "dp" autour du bouton.
        ) {
            Text(                                                                                    // Affiche un texte à l'intérieur du bouton.
                text = if (language == "fr") "Changer en Anglais" else "Switch to French",           // Le texte du bouton dépend de la langue : en français ou en anglais.
                color = Color.White,                                                                 // Définit la couleur du texte en blanc.
                fontSize = 18.sp,                                                                   // Définit la taille de la police du texte à 18 "sp" (scale-independent pixels).
                fontWeight = FontWeight.SemiBold                                                    // Applique un poids de police semi-gras.
            )
        }
    }
}




@Composable
fun SignupForm(onBack: () -> Unit) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("fr") }

    // Variables d'état pour les messages d'erreur
    var emailError by remember { mutableStateOf<String?>(null) }
    var birthDateError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }

    fun changeLanguage(lang: String) {
        language = lang
    }

    val titleText = if (language == "fr") "Formulaire d'Inscription" else "Signup Form"
    val firstNameLabel = if (language == "fr") "Prénom" else "First Name"
    val lastNameLabel = if (language == "fr") "Nom" else "Last Name"
    val emailLabel = if (language == "fr") "Adresse Mail" else "Email Address"
    val birthDateLabel = if (language == "fr") "Date d'anniversaire" else "Birth Date"
    val passwordLabel = if (language == "fr") "Mot de passe" else "Password"
    val confirmPasswordLabel = if (language == "fr") "Confirmer le mot de passe" else "Confirm Password"
    val signupButtonText = if (language == "fr") "S'inscrire" else "Sign Up"
    val backButtonText = if (language == "fr") "Retour" else "Back"
    val changeLangButtonText = if (language == "fr") "Changer en Anglais" else "Change to French"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .background(color = Color.White, shape = RoundedCornerShape(20.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = titleText,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0288D1),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Champs de texte
        TextField(value = firstName, onValueChange = { firstName = it }, label = { Text(firstNameLabel) })
        Spacer(modifier = Modifier.height(8.dp))
        TextField(value = lastName, onValueChange = { lastName = it }, label = { Text(lastNameLabel) })
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = email,
            onValueChange = {
                email = it
                emailError = if ( it.contains(".com")) null else "Email invalide"
            },
            label = { Text(emailLabel) }
        )
        emailError?.let {
            Text(text = it, color = Color.Red, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = birthDate,
            onValueChange = {
                birthDate = it
                birthDateError = if (it.all { char -> char.isDigit() }) null else "La date doit contenir uniquement des chiffres"
            },
            label = { Text(birthDateLabel) }
        )
        birthDateError?.let {
            Text(text = it, color = Color.Red, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text(passwordLabel) },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = confirmPassword,
            onValueChange = {
                confirmPassword = it
                passwordError = if (password == it) null else "Les mots de passe ne correspondent pas"
            },
            label = { Text(confirmPasswordLabel) },
            visualTransformation = PasswordVisualTransformation()
        )
        passwordError?.let {
            Text(text = it, color = Color.Red, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Boutons
        Button(
            onClick = {
                if (emailError == null && birthDateError == null && passwordError == null &&
                    firstName.isNotBlank() && lastName.isNotBlank()
                ) {
                    println("Inscription réussie")
                } else {
                    println("Veuillez corriger les erreurs")
                }
            },
            colors = ButtonDefaults.buttonColors(Color(0xFF03A9F4)),
            shape = RoundedCornerShape(50),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(signupButtonText, color = Color.White, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onBack,
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),
            shape = RoundedCornerShape(50),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(backButtonText, color = Color.White, fontSize = 16.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { changeLanguage(if (language == "fr") "en" else "fr") },
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),
            shape = RoundedCornerShape(50),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(changeLangButtonText, color = Color.White, fontSize = 16.sp)
        }
    }
}




//INTERFACE: ECRAN DE RECHERCHE//
@Composable
fun SearchScreen(onBack: () -> Unit, onSearch: (String) -> Unit) {                                  // Déclare la fonction "SearchScreen"
    var searchQuery by remember { mutableStateOf("") }                                        //  stocke la requête de recherche
    var language by remember { mutableStateOf("fr") }                                         // Variable pour gérer la langue de l'interface
    var showBanner by remember { mutableStateOf(false) }                                       //Variable pour afficher ou masquer une bannière

    // Fonction pour changer la langue de l'interface
    fun changeLanguage(lang: String) {                                                              // Permet de changer la langue de l'interface.
        language = lang                                                                             // Met à jour la variable
    }


    // Textes multilingues : définit les textes en fonction de la langue choisie
    val titleText = if (language == "fr") "Écran de Recherche" else "Search Screen"                 // Titre de l'écran selon la langue.
    val searchLabel = if (language == "fr") "Rechercher un vol" else "Search a flight"              // Texte de l'étiquette de recherche.
    val searchButtonText = if (language == "fr") "Rechercher" else "Search"                         // Texte du bouton de recherche.
    val backButtonText = if (language == "fr") "Retour" else "Back"                                 // Texte du bouton de retour.
    val changeLangButtonText = if (language == "fr") "Changer en Anglais" else "Change to French"   // Texte du bouton pour changer de langue.
    val greenButtonText = if (language == "fr") "GOOGLE MAPS" else "GOOGLE MAPS"                    // Texte du bouton "Google Maps"

// Exemple de liste de vols (exemple fictif pour la démonstration)
    val flights = listOf(                                                                           // Crée une liste de chaînes représentant des vols.
        "Vol Paris - Londres",                                                                      // Vol entre Paris et Londres.
        "Vol Paris - New York",                                                                     // Vol entre Paris et New York.
        "Vol Paris - Tokyo",                                                                        // Vol entre Paris et Tokyo.
        "Vol Paris - Sydney",                                                                       // Vol entre Paris et Sydney.
        "Vol Paris - Berlin",                                                                       // Vol entre Paris et Berlin.
        "Vol Paris - Rome"                                                                          // Vol entre Paris et Rome.
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()                                                                         // Remplit toute la largeur disponible de l'écran
            .padding(horizontal = 24.dp, vertical = 16.dp)                                           // Ajoute des marges de 24dp horizontalement et 16dp verticalement
            .background(
                color = Color(0xFFBBDEFB),                                                    // Définit la couleur de fond de la colonne (bleu clair)
                shape = RoundedCornerShape(20.dp)                                                   // Applique un rayon de bordure de 20dp pour des coins arrondis
            )
            .padding(16.dp),                                                                        // Ajoute un padding interne de 16dp autour du contenu de la colonne
        horizontalAlignment = Alignment.CenterHorizontally,                                         // Aligne horizontalement les enfants de la colonne au centre
        verticalArrangement = Arrangement.Center                                                    // Aligne verticalement les enfants de la colonne au centre
    ) {
        // Affichage de la bannière si showBanner est vrai
        if (showBanner) {
            Text(
                text = "Veuillez ouvrir la page : https://www.google.fr/maps",                       //Rediriger vers la page  maps
                color = Color(0xFF0288D1),                                                    // Texte bleu
                fontSize = 16.sp,                                                                   // Taille de texte réduite
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)                                                        // Bannière blanche
                    .padding(12.dp)                                                                 // Moins de padding pour une bannière plus compacte
                    .clickable { showBanner = false },                                               // Disparaît au clic
                textAlign = TextAlign.Center
            )
        }

        // Titre
// Affichage du titre de l'écran
        Text(
            text = titleText,                                                                        // Le texte à afficher est contenu dans la variable `titleText`, qui est dynamique selon la langue (français ou anglais)
            fontSize = 20.sp,                                                                        // Taille de la police du texte est de 20sp
            fontWeight = FontWeight.Bold,                                                            // Le texte est en gras (police en gras)
            color = Color(0xFF0288D1),                                                         // La couleur du texte est définie par un code hexadécimal bleu
            textAlign = TextAlign.Center                                                             // Le texte est centré horizontalement
        )

        Spacer(modifier = Modifier.height(16.dp))                                                   // Ce Spacer ajoute un espace vertical de 16dp sous le titre pour espacer le contenu


        // Barre de recherche
        TextField(
            value = searchQuery,                                                                    // La valeur actuelle de la barre de recherche
            onValueChange = { searchQuery = it },                                                   // Met à jour la valeur de la recherche lorsque l'utilisateur tape
            label = { Text(searchLabel) },                                                          // Affiche le label de la barre de recherche
            modifier = Modifier
                .fillMaxWidth()                                                                     // Remplit toute la largeur disponible
                .padding(vertical = 4.dp)                                                           // Ajoute un espacement vertical de 4dp autour du TextField
        )

        Spacer(modifier = Modifier.height(8.dp))                                                    // Ajoute un espace vertical de 8dp après la barre de recherche

// Ligne avec les boutons de recherche et le nouveau bouton vert
        Row(
            modifier = Modifier.fillMaxWidth(),                                                      // La ligne occupe toute la largeur disponible
            horizontalArrangement = Arrangement.spacedBy(8.dp)                                      // Ajoute un espacement de 8dp entre les éléments de la ligne
        ) {
            // Bouton de recherche
            Button(                                                                                 // Crée un bouton interactif.
                onClick = { onSearch(searchQuery) },                                                // Définit l'action à effectuer lorsque le bouton est cliqué
                colors = ButtonDefaults.buttonColors(Color(0xFF03A9F4)),                      // Définit la couleur de fond du bouton (couleur bleue ici).
                shape = RoundedCornerShape(50),                                             // Donne au bouton des coins arrondis avec un rayon de 50.
                modifier = Modifier                                                                 // Applique des modifications au bouton.
                    .weight(1f)                                                                     // Le bouton prend un poids égal (répartition flexible dans une mise en page).
                    .height(50.dp)                                                                  // Définit la hauteur du bouton à 50 "dp" (density-independent pixels).
            ) {
                Text(searchButtonText, color = Color.White, fontSize = 16.sp)                        // Affiche le texte sur le bouton, avec un texte blanc et une taille de 16 "sp".
            }


            // Nouveau bouton vert ajouté
            Button(
                onClick = {
                    // Lorsque le bouton vert est cliqué, on affiche la bannière en définissant showBanner à true
                    showBanner = true
                },
                colors = ButtonDefaults.buttonColors(Color(0xFF4CAF50)),                      // Définit la couleur du bouton en vert
                shape = RoundedCornerShape(50),                                             // Bouton avec des bords arrondis (rayon de 50dp)
                modifier = Modifier
                    .weight(1f)                                                                     // Attribue une largeur proportionnelle au bouton
                    .height(50.dp)                                                                  // Définit une hauteur fixe de 50dp pour le bouton
            ) {
                Text(greenButtonText, color = Color.White, fontSize = 16.sp)                         // Taille du texte
            }
        }

        // Espacement entre les éléments
        Spacer(modifier = Modifier.height(16.dp)) // Ajoute un espacement vertical de 16dp

// Liste défilante des vols
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()                                                                     // La liste défilante occupe toute la largeur de l'écran
                .height(200.dp)                                                                      // La hauteur de la liste est limitée à 200dp, activant ainsi le défilement
        ) {
            // Pour chaque vol dans la liste `flights`
            items(flights) { flight ->
                // Affichage de chaque vol
                Text(
                    text = flight,                                                                  // Le texte du vol
                    modifier = Modifier
                        .fillMaxWidth()                                                             // Le texte occupe toute la largeur de la liste
                        .padding(vertical = 8.dp)                                                   // Un espacement vertical de 8dp autour du texte
                        .background(Color(0xFFE3F2FD), shape = RoundedCornerShape(10.dp))      // Fond bleu clair avec des bords arrondis
                        .padding(16.dp)                                                              // Un padding interne de 16dp
                        .clickable {                                                                // Lorsque l'on clique sur un vol
                            searchQuery = flight                                                    // Le vol sélectionné est copié dans la barre de recherche
                        },
                    color = Color(0xFF0288D1),                                                 // La couleur du texte est bleu (couleur hexadécimale #0288D1)
                    fontSize = 16.sp                                                                 // La taille de la police est de 16sp
                )
            }
        }


        // Espacement vertical entre les éléments
        Spacer(modifier = Modifier.height(8.dp))                                                     // Ajoute un espacement de 8dp entre les éléments

// Bouton retour
        Button(
            onClick = onBack,                                                                       // Action à effectuer lorsqu'on clique sur le bouton : fonction onBack (par exemple, revenir à l'écran précédent)
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                           // Couleur de fond du bouton (bleu)
            shape = RoundedCornerShape(50),                                                  // Bords arrondis du bouton avec un rayon de 50dp
            modifier = Modifier
                .fillMaxWidth()                                                                     // Le bouton occupe toute la largeur disponible
                .height(50.dp)                                                                      // La hauteur du bouton est fixée à 50dp
        ) {
            // Texte du bouton
            Text(
                backButtonText,                                                                     // Le texte du bouton est celui défini par la variable backButtonText
                color = Color.White,                                                                // La couleur du texte est blanche
                fontSize = 16.sp                                                                    // La taille de la police est de 16sp
            )
        }


        // Espacement vertical entre les éléments
        Spacer(modifier = Modifier.height(8.dp)) // Ajoute un espacement de 8dp entre les éléments

// Bouton changer langue
        Button(
            onClick = { changeLanguage(if (language == "fr") "en" else "fr") },                     // Lorsque le bouton est cliqué, il change la langue. Si la langue actuelle est le français ("fr"), elle passe à l'anglais ("en") et vice-versa.
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                          // Couleur de fond du bouton (bleu)
            shape = RoundedCornerShape(50),                                                  // Le bouton a des bords arrondis avec un rayon de 50dp
            modifier = Modifier
                .fillMaxWidth()                                                                      // Le bouton occupe toute la largeur disponible
                .height(50.dp)                                                                       // La hauteur du bouton est fixée à 50dp
        ) {
            // Texte du bouton
            Text(
                changeLangButtonText,                                                               // Le texte du bouton est celui défini par la variable changeLangButtonText
                color = Color.White,                                                                 // La couleur du texte est blanche pour contraster avec le bleu
                fontSize = 16.sp                                                                    // La taille du texte est de 16sp
            )
        }

    }
}






//INTERFACE POUR LA VALIDATION DE LA DATE//
@Composable
fun ValidationScreen(onBack: () -> Unit, onGoToScan: () -> Unit) {
    var selectedDate by remember { mutableStateOf("") }                                        // Variable pour stocker la date sélectionnée
    var selectedTime by remember { mutableStateOf("") }                                        // Variable pour stocker l'heure sélectionnée
    var language by remember { mutableStateOf("fr") }                                         // Variable pour la langue actuelle (français par défaut)
    var errorMessage by remember { mutableStateOf("") }                                       // Variable pour les messages d'erreur
    var showTimePicker by remember { mutableStateOf(false) }                                  // Variable pour afficher ou non le sélecteur d'heure

    // Liste dynamique des dates et heures disponibles selon la langue choisie
    val availableDatesAndTimes = remember {
        if (language == "fr") {
            mapOf(  // En français
                "05/02/2025" to listOf("10:00", "14:00", "16:00"),                                   // Date et heures disponibles
                "12/03/2025" to listOf("09:00", "13:00", "15:00"),
                "11/12/2025" to listOf("08:00", "12:00", "18:00")
            )
        } else {
            mapOf(  // En anglais
                "02/05/2025" to listOf("10:00 AM", "2:00 PM", "4:00 PM"),                           // Date et heures formatées en anglais
                "03/12/2025" to listOf("9:00 AM", "1:00 PM", "3:00 PM"),
                "12/11/2025" to listOf("8:00 AM", "12:00 PM", "6:00 PM")
            )
        }
    }

    // Textes en fonction de la langue sélectionnée (français/anglais)
    val titleText = if (language == "fr") "Choisissez une Date :" else "Choose a Date:"              // Titre du champ de sélection de la date
    val timeText = if (language == "fr") "Choisissez une Heure :" else "Choose a Time:"             // Titre du champ de sélection de l'heure
    val validateButtonText = if (language == "fr") "Valider" else "Validate"                        // Texte du bouton de validation
    val backButtonText = if (language == "fr") "Retour" else "Back"                                 // Texte du bouton de retour
    val changeLangButtonText = if (language == "fr") "Changer en Anglais" else "Change to English"  // Texte du bouton pour changer la langue
    val errorText = if (language == "fr") "ERREUR : Veuillez choisir une date et une heure SVP" else "ERROR: Please select a date and time"  // Message d'erreur


    Column(
        modifier = Modifier
            .fillMaxWidth()                                                                         // La colonne prend toute la largeur disponible
            .padding(horizontal = 24.dp, vertical = 16.dp)                                          // Ajoute une marge autour de la colonne
            .background(
                color = Color(0xFFBBDEFB),                                                    // Définit une couleur de fond bleue claire
                shape = RoundedCornerShape(20.dp)                                                   // Arrondit les coins avec un rayon de 20dp
            )
            .padding(16.dp),                                                                        // Ajoute un espacement intérieur à la colonne
        horizontalAlignment = Alignment.CenterHorizontally,                                         // Centre tous les éléments horizontalement
        verticalArrangement = Arrangement.Center                                                    // Centre les éléments verticalement
    ) {
        // Titre de la section ou de l'écran
        Text(
            text = titleText,                                                                       // Texte dynamique passé en paramètre
            fontSize = 20.sp,                                                                       // Définit la taille de la police
            fontWeight = FontWeight.Bold,                                                           // Met le texte en gras
            color = Color(0xFF0288D1),                                                              // Définit une couleur bleue pour le texte
            textAlign = TextAlign.Center                                                            // Centre le texte horizontalement
        )

        Spacer(modifier = Modifier.height(16.dp))                                                   // Ajoute un espace vertical de 16dp pour séparer les éléments visuellement

// Liste des dates disponibles
        availableDatesAndTimes.keys.forEach { date ->                                               // Parcourt toutes les dates disponibles (les clés de la map)
            Button(
                onClick = {
                    selectedDate = date                                                              // Met à jour la date sélectionnée
                    showTimePicker = true                                                            // Affiche le sélecteur d'heure après la sélection d'une date
                },
                colors = ButtonDefaults.buttonColors(
                    // Change la couleur du bouton en fonction de la date sélectionnée
                    if (selectedDate == date) Color(0xFF388E3C) else Color(0xFFE53935)    // Vert si sélectionnée, rouge sinon
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier                                                                 // Affiche la date correspondante sur le bouton
                    .fillMaxWidth()                                                                 // Couleur du texte en blanc pour contraster avec le fond
                    .padding(vertical = 4.dp)                                                       // Taille de police pour le texte du bouton
            ) {
                Text(                                                                               // Affiche un composable "Text" pour afficher du texte à l'écran.
                    text = date,                                                                    // Affiche la variable "date" (qui contient probablement une date ou heure).
                    color = Color.White,                                                            // Définit la couleur du texte en blanc.
                    fontSize = 16.sp                                                                // Définit la taille de la police à 16 "sp"
                )

            }
        }

        Spacer(modifier = Modifier.height(16.dp))                                                   // Espacement de 16dp avant l'affichage des heures disponibles

// Affichage des heures disponibles si une date est sélectionnée
        if (showTimePicker && selectedDate.isNotEmpty()) {                                          // Vérifie si l'heure peut être affichée et si une date a été sélectionnée
            Text(
                text = timeText,                                                                    // Affiche le texte des heures disponibles
                fontSize = 18.sp,                                                                   // Taille de la police pour le texte
                fontWeight = FontWeight.Bold,                                                        // Mise en gras du texte
                color = Color(0xFF0288D1),                                                    // Couleur bleue pour le texte
                textAlign = TextAlign.Center                                                        // Centrer le texte
            )
            Spacer(modifier = Modifier.height(8.dp))                                                 // Espacement de 8dp après le texte

            availableDatesAndTimes[selectedDate]?.forEach { time ->                                  // Itère sur les heures disponibles pour la date sélectionnée
                Button(
                    onClick = { selectedTime = time },                                              // Lors du clic, met à jour l'heure sélectionnée
                    colors = ButtonDefaults.buttonColors(                                            // Changer la couleur du bouton selon si l'heure est sélectionnée
                        if (selectedTime == time) Color(0xFF388E3C) else Color(0xFFE53935) // Vert si sélectionné, rouge sinon
                    ),
                    shape = RoundedCornerShape(50),                                         // Forme arrondie pour le bouton
                    modifier = Modifier                                                             // Modifications du bouton
                        .fillMaxWidth()                                                             // Bouton prend toute la largeur disponible
                        .padding(vertical = 4.dp)                                                   // Espacement vertical autour du bouton
                ) {
                    Text(
                        text = time,                                                                 // Affiche l'heure dans le bouton
                        color = Color.White,                                                        // Texte en blanc
                        fontSize = 16.sp                                                            // Taille de la police du texte
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))                                                   // Espacement de 16dp après les heures disponibles

// Afficher un message d'erreur en rouge si nécessaire
        if (errorMessage.isNotEmpty()) {                                                             // Vérifie s'il y a un message d'erreur
            Text(
                text = errorMessage,                                                                // Affiche le message d'erreur
                color = Color.Red,                                                                  // Couleur rouge pour l'erreur
                fontSize = 14.sp,                                                                   // Taille de la police pour le texte d'erreur
                textAlign = TextAlign.Center                                                        // Centrer le texte
            )
            Spacer(modifier = Modifier.height(8.dp))                                                // Espacement de 8dp après le message d'erreur
        }

// Boutons de validation et retour
        Button(
            onClick = { // Action pour le bouton de validation
                if (selectedDate.isNotEmpty() && selectedTime.isNotEmpty()) {                       // Vérifie si une date et une heure sont sélectionnées
                    onGoToScan()                                                                    // Exécute l'action de passage à l'écran de scan
                } else {
                    errorMessage = errorText                                                         // Affiche un message d'erreur si l'un des champs est vide
                }
            },
            colors = ButtonDefaults.buttonColors(Color(0xFF03A9F4)),                           // Couleur bleue pour le bouton
            shape = RoundedCornerShape(50),                                                  // Forme arrondie pour le bouton
            modifier = Modifier                                                                     // Modifications du bouton
                .fillMaxWidth()                                                                      // Bouton prend toute la largeur disponible
                .height(50.dp)                                                                      // Hauteur du bouton
        ) {
            Text(validateButtonText, color = Color.White, fontSize = 16.sp)                         // Affiche le texte du bouton de validation en blanc
        }

        Spacer(modifier = Modifier.height(8.dp))                                                    // Espacement de 8dp avant le bouton retour

        Button(
            onClick = onBack,                                                                       // Action pour le bouton de retour
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                          // Couleur bleue pour le bouton
            shape = RoundedCornerShape(50),                                                 // Forme arrondie pour le bouton
            modifier = Modifier                                                                     // Modifications du bouton
                .fillMaxWidth()                                                                     // Bouton prend toute la largeur disponible
                .height(50.dp)                                                                      // Hauteur du bouton
        ) {
            Text(backButtonText, color = Color.White, fontSize = 16.sp)                             // Affiche le texte du bouton de retour en blanc
        }

        Spacer(modifier = Modifier.height(8.dp))                                                     // Espacement de 8dp après le bouton retour


        Button(                                                                                      // Bouton pour changer la langue
            onClick = {                                                                             // Action à effectuer lors du clic sur le bouton
                language = if (language == "fr") "en" else "fr"                                     // Si la langue est "fr", la changer en "en", sinon en "fr"
            },
            colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                           // Définir la couleur du bouton avec un bleu personnalisé
            shape = RoundedCornerShape(50),                                                 // Donner une forme arrondie au bouton avec un rayon de 50dp
            modifier = Modifier                                                                     // Appliquer des modificateurs au bouton
                .fillMaxWidth()                                                                     // Faire en sorte que le bouton prenne toute la largeur disponible
                .height(50.dp)                                                                      // Définir la hauteur du bouton à 50dp
        ) {
            Text(changeLangButtonText, color = Color.White, fontSize = 16.sp)                       // Afficher le texte du bouton avec la couleur blanche et une taille de police de 16sp
        }

    }
}






//NOUVELLE INTERFACE : SCANNER LE TICKET//
@Composable
fun ScanScreen(onBack: () -> Unit) {
    var language by remember { mutableStateOf("fr") }                                         // Variable pour la langue
    var showBar by remember { mutableStateOf(false) }                                         // État pour afficher la barre
    var showBanner by remember { mutableStateOf(false) }                                      // État pour afficher la bannière de notification

    // Fonction pour changer la langue
    fun changeLanguage(lang: String) {
        language = lang
    }

    // Déterminer les textes à afficher en fonction de la langue
    // Textes en fonction de la langue sélectionnée (français/anglais)
    val titleText = if (language == "fr") "Scanner le Ticket" else "Scan the Ticket"                // Titre de la page pour scanner le ticket
    val instructionText = if (language == "fr") "Placez votre ticket sous le scanner." else "Place your ticket under the scanner."  // Instruction pour l'utilisateur sur où placer le ticket
    val backButtonText = if (language == "fr") "Retour" else "Back"                                 // Texte du bouton de retour
    val changeLangButtonText = if (language == "fr") "Changer en Anglais" else "Change to English"   // Texte du bouton pour changer la langue
    val openCameraButtonText = if (language == "fr") "Ouvrir l'appareil photo" else "Open Camera"    // Texte du bouton pour ouvrir l'appareil photo
    val bannerText = if (language == "fr") "Ouvrir l'appareil photo" else "Open Camera"             // Texte affiché dans la bannière pour ouvrir l'appareil photo


    // Conteneur principal de la colonne qui occupe toute la taille de l'écran
    Column(
        modifier = Modifier.fillMaxSize()                                                           // Remplit toute la taille de l'écran
    ) {
        // Afficher la bannière de notification
        if (showBanner) {
            // Box contenant la bannière
            Box(
                modifier = Modifier
                    .fillMaxWidth()                                                                 // La bannière occupe toute la largeur de l'écran
                    .background(Color(0xFFFFC107))                                             // Couleur de fond de la bannière (jaune-orangé)
                    .padding(8.dp),                                                                  // Ajoute un padding autour du texte
                contentAlignment = Alignment.Center                                                 // Aligne le texte au centre de la boîte
            ) {
                // Texte à l'intérieur de la bannière
                Text(
                    text = bannerText,                                                              // Le texte de la bannière
                    color = Color.Black,                                                            // Couleur du texte
                    fontSize = 16.sp,                                                                // Taille de la police
                    fontWeight = FontWeight.Bold                                                    // Texte en gras
                )
            }

            // La bannière disparaît après 3 secondes
            LaunchedEffect(Unit) {
                delay(3000)                                                                // Attendre 3000 millisecondes (3 secondes)
                showBanner = false                                                                  // Masquer la bannière après 3 secondes
            }
        }

        // Barre en haut de l'écran (affichage conditionnel)
        if (showBar) {
            // Box contenant la barre
            Box(
                modifier = Modifier
                    .fillMaxWidth()                                                                 // La barre occupe toute la largeur de l'écran
                    .background(Color.Green)                                                        // Couleur de fond de la barre (verte)
                    .padding(8.dp),                                                                 // Padding autour du contenu de la barre
                contentAlignment = Alignment.Center                                                 // Aligne le contenu au centre de la bare
            ) {
                Text(                                                                               // Affiche un composable "Text" pour afficher du texte à l'écran.
                    text = if (language == "fr") "Notification: Ticket scanné" else "Ticket scanned", // Le texte affiché  : en français ou en anglais.
                    color = Color.White,                                                            // Définit la couleur du texte en blanc.
                    fontSize = 16.sp,                                                               // Définit la taille de la police à 16 "sp" (scale-independent pixels).
                    fontWeight = FontWeight.Bold                                                    // Définit la police en gras.
                )

            }
        }

        // Contenu principal
        Column(
            modifier = Modifier
                .fillMaxWidth()                                                                      // Le composant occupe toute la largeur disponible
                .padding(horizontal = 24.dp, vertical = 16.dp)                                       // Ajoute un espacement de 24dp horizontal et 16dp vertical autour de la colonne
                .background(
                    color = Color(0xFFBBDEFB),                                                 // Définir la couleur de fond de la colonne en bleu clair (code hexadécimal #BBDEFB)
                    shape = RoundedCornerShape(20.dp)                                               // Applique des coins arrondis avec un rayon de 20dp
                )
                .padding(16.dp),                                                                    // Ajoute un espacement interne de 16dp autour du contenu de la colonne
            horizontalAlignment = Alignment.CenterHorizontally,                                     // Aligne les éléments enfants horizontalement au centre de la colonne
            verticalArrangement = Arrangement.Center                                                 // Aligne les éléments enfants verticalement au centre de la colonne
        ) {
            Text(
                text = titleText,                                                                   // Le texte à afficher, ici une variable `titleText` (qui peut être dynamique selon la langue)
                fontSize = 20.sp,                                                                   // La taille du texte est définie sur 20sp (scaled pixels), une unité indépendante de la densité de l'écran
                fontWeight = FontWeight.Bold,                                                       // Applique une police en gras pour mettre en valeur le texte
                color = Color(0xFF0288D1),                                                    // Définie la couleur du texte en bleu avec le code hexadécimal #0288D1
                textAlign = TextAlign.Center                                                        // Aligne le texte horizontalement au centre du composant parent (par exemple, une `Column`)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = instructionText,                                                              // Le texte à afficher, ici la variable `instructionText` (qui est aussi dynamique en fonction de la langue)
                fontSize = 16.sp,                                                                   // La taille du texte est de 16sp (scaled pixels), ce qui est adapté à la lisibilité
                color = Color.Black,                                                                // Le texte est en couleur noire
                textAlign = TextAlign.Center                                                        // Aligne le texte horizontalement au centre du composant parent
            )

            Spacer(modifier = Modifier.height(32.dp))                                               // Ajoute un espace de 32 dp  entre les éléments


            // Premier bouton : Simule le scan et affiche la barre
            Button(
                onClick = {
                    // Simule un scan et affiche la barre
                    showBar = true  // Lors du clic sur ce bouton, l'état de `showBar` est mis à `true`, ce qui déclenche l'affichage d'une barre (par exemple, une barre de notification ou une barre de progression)
                },
                colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                       // Le bouton utilise une couleur bleue personnalisée
                shape = RoundedCornerShape(50),                                              // Le bouton a des bords arrondis avec un rayon de 50dp pour une forme circulaire
                modifier = Modifier
                    .fillMaxWidth()                                                                  // Le bouton prend toute la largeur disponible
                    .height(50.dp)                                                                  // Le bouton a une hauteur de 50dp
            ) {
                Text("Scanner", color = Color.White, fontSize = 16.sp)                          // Le texte à afficher sur le bouton est "Scanner" avec une couleur de texte blanche et une taille de police de 16sp
            }

            Spacer(modifier = Modifier.height(8.dp))                                                // Ajout d'un espace de 8dp pour séparer les éléments

// Deuxième bouton : Changer la langue
            Button(
                onClick = {
                    // Changer la langue
                    changeLanguage(if (language == "fr") "en" else "fr")  // Lors du clic sur ce bouton, on change la langue de l'interface entre français et anglais en appelant `changeLanguage`
                },
                colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),  // Comme le bouton précédent, ce bouton utilise la couleur bleue personnalisée
                shape = RoundedCornerShape(50),  // Le bouton a également des bords arrondis avec un rayon de 50dp
                modifier = Modifier
                    .fillMaxWidth()  // Ce bouton prend également toute la largeur disponible
                    .height(50.dp)  // Ce bouton a une hauteur de 50dp
            ) {
                Text(changeLangButtonText, color = Color.White, fontSize = 16.sp)  // Le texte du bouton est défini par la variable `changeLangButtonText`, qui contient le texte dynamique en fonction de la langue actuelle
            }

            Spacer(modifier = Modifier.height(8.dp))                                                // Ajout d'un autre espace de 8dp pour séparer les boutons


            Button(
                onClick = onBack,                                                                    // Lorsque le bouton est cliqué, l'action `onBack` est exécutée
                colors = ButtonDefaults.buttonColors(Color(0xFF0288D1)),                      // Définit la couleur du bouton (bleu ici)
                shape = RoundedCornerShape(50),                                              // Applique des coins arrondis avec un rayon de 50 pour un bouton circulaire
                modifier = Modifier
                    .fillMaxWidth()                                                                  // Le bouton occupe toute la largeur disponible
                    .height(50.dp)                                                                  // La hauteur du bouton est de 50dp
            ) {
                Text(backButtonText, color = Color.White, fontSize = 16.sp)                         // Affiche le texte du bouton (texte blanc, taille 16sp)
            }

            Spacer(modifier = Modifier.height(8.dp))                                                 // Espacement de 8dp entre ce bouton et l'élément suivant


            // Nouveau bouton orange-jaune
            Button(
                onClick = {// Afficher la bannière lorsque l'on clique sur le bouton
                    showBanner = true  // Lorsque le bouton est cliqué, on modifie la variable showBanner pour afficher la bannière
                },
                colors = ButtonDefaults.buttonColors(Color(0xFFFFC107)),                       // Couleur orange-jaune (code hexadécimal)
                shape = RoundedCornerShape(50),                                              // Le bouton a des coins arrondis avec un rayon de 50
                modifier = Modifier
                    .fillMaxWidth()                                                                  // Le bouton occupe toute la largeur disponible
                    .height(50.dp)                                                                  // Le bouton a une hauteur fixe de 50 dp
            ) {
                // Le texte à l'intérieur du bouton
                Text(
                    openCameraButtonText,                                                            // Affiche le texte qui est passé en paramètre (variable openCameraButtonText)
                    color = Color.Black,                                                             // Le texte du bouton est en noir
                    fontSize = 16.sp                                                                 // La taille du texte est de 16 sp (scale-independent pixels)
                )
            }

        }
    }
}


// Affiche un aperçu de la fonction dans Android Studio avec un fond.
@Preview(showBackground = true)                                                                      // Affiche un aperçu de la fonction dans l'éditeur Android Studio.
@Composable
fun PreviewMainContent() {                                                                          // Déclaration de la fonction PreviewMainContent.
    TrackerPlaneTheme {                                                                             // Applique le thème de l'application.
        MainContent(
            modifier = Modifier                                                                     // Définit les modifications du composant avec un Modifier.
                .fillMaxSize()                                                                      // Remplit tout l'espace disponible dans le parent.
                .background(                                                                        // Applique un fond à l'élément.
                    brush = Brush.verticalGradient(                                                 // Utilise un dégradé vertical comme fond.
                        colors = listOf(Color(0xFFB3E5FC), Color(0xFF03A9F4))           // couleur
                    )
                )
        )
    }
}